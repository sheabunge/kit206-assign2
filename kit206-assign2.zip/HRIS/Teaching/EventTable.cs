﻿using System;

namespace HRIS.Teaching {
	public class EventTable {
		public int MaxFrequency { get; set; }

		public int FrequencyAt(int hour, DayOfWeek dayofweek) {
			return 0;
		}
	}
}
