﻿namespace HRIS.Teaching {
	public enum Campus {
		Hobart,
		Launceston,
	}
}
