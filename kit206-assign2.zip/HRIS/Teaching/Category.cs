﻿namespace HRIS.Teaching {
	public enum Category {
		Any,
		Academic,
		Technical,
		Admin,
		Casual,
	}
}
