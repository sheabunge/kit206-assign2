﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace HRIS.Teaching {
	public enum Availability {
		Free,
		Consulting,
		Teaching,
	}
}
