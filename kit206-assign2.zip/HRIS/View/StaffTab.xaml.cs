﻿using HRIS.Control;
using HRIS.Teaching;
using System;
using System.Windows;
using System.Windows.Controls;

namespace HRIS.View {
	/// <summary>
	/// Interaction logic for StaffTab.xaml
	/// </summary>
	public partial class StaffTab : UserControl {
		private readonly StaffController controller;

		public StaffTab() {
			controller = (StaffController) Application.Current.FindResource("StaffController");

		}
	}
}
